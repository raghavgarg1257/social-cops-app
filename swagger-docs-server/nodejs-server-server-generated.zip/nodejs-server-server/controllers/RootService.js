'use strict';

exports.getRoot = function(args, res, next) {
  /**
   * Shows a text message
   * 
   *
   * no response value expected for this operation
   **/
  res.end();
}

exports.postRoot = function(args, res, next) {
  /**
   * Shows a text message
   * 
   *
   * no response value expected for this operation
   **/
  res.end();
}

