'use strict';

exports.applyJsonPatch = function(args, res, next) {
  /**
   * Apply json patch to the JSON Object.
   * 
   *
   * body Body 
   * no response value expected for this operation
   **/
  res.end();
}

