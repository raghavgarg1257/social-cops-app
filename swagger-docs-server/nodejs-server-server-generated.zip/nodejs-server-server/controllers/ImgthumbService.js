'use strict';

exports.createThumbnail = function(args, res, next) {
  /**
   * Convert public image url to 50x50 pixel thumbnail.
   * 
   *
   * url String The public image url
   * no response value expected for this operation
   **/
  res.end();
}

